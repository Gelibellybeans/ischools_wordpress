<?php
/**
 * @file
 * breadcrumb file template
 */
// TODO: add a widget that can replace the default breadcrumb
?>
<div id="breadcrumbs">
	<div class="row">
		<div class="large-12 columns">
    <?php gwt_wp_breadcrumb(); ?>
		</div>
	</div>
</div>